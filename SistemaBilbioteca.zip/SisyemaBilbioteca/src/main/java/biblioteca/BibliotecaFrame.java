
package biblioteca;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class BibliotecaFrame extends JFrame {

    // Componentes creados en el diseñador visual de IntelliJ
    private JTable tabla;
    private JTextField txtCodigo;
    private JTextField txtTitulo;
    private JTextField txtAutor;
    private JTextField txtSolicitante;

    private JLabel lblCodigo;
    private JLabel lblTituloLibro;
    private JLabel lblAutor;
    private JLabel lblSolicitante;
    private JButton btnRegistrar;
    private JButton btnBuscar;
    private JButton btnMostrar;
    private JButton btnSolicitar;
    private JButton btnAtender;
    private JButton btnDevolver;
    private JLabel lblResumen;
    private JLabel lblTitulo;

    private JPanel panelTitulo;
    private JPanel panelPrincipal;
    private JPanel panelTabla;
    private JPanel panelBotones;
    private JPanel panelFormulario;

    // Estructuras de datos
    private final ListaLibros lista = new ListaLibros();
    private final ArbolBusqueda arbol = new ArbolBusqueda();
    private final ColaPrestamos cola = new ColaPrestamos();

    // Modelo de la tabla
    private final DefaultTableModel modelo =
            new DefaultTableModel(
                    new Object[]{"Código", "Título", "Autor", "Estado"}, 0) {

                @Override
                public boolean isCellEditable(int fila, int columna) {
                    return false;
                }
            };

    public BibliotecaFrame() {

        // Utilizar el formulario diseñado manualmente
        setContentPane(panelPrincipal);

        setTitle("Biblioteca Virtual");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(950, 600);
        setLocationRelativeTo(null);

        // Configurar tabla
        tabla.setModel(modelo);
        tabla.setRowHeight(25);

        // Libros de ejemplo
        registrarEjemplo(
                "L003",
                "Cien años de soledad",
                "Gabriel García Márquez");

        registrarEjemplo(
                "L001",
                "Don Quijote de la Mancha",
                "Miguel de Cervantes");

        registrarEjemplo(
                "L002",
                "La ciudad y los perros",
                "Mario Vargas Llosa");

        // Acciones de los botones
        btnRegistrar.addActionListener(e -> registrarLibro());
        btnBuscar.addActionListener(e -> buscarLibro());
        btnMostrar.addActionListener(e -> mostrarTodos());
        btnSolicitar.addActionListener(e -> solicitarPrestamo());
        btnAtender.addActionListener(e -> atenderSolicitud());
        btnDevolver.addActionListener(e -> devolverLibro());

        mostrarTodos();
    }

    // Agregar libros iniciales
    private void registrarEjemplo(
            String codigo, String titulo, String autor) {

        Libro libro = new Libro(codigo, titulo, autor);
        lista.agregar(libro);
        arbol.insertar(libro);
    }

    // Registrar un nuevo libro
    private void registrarLibro() {

        String codigo = txtCodigo.getText().trim();
        String titulo = txtTitulo.getText().trim();
        String autor = txtAutor.getText().trim();

        if (codigo.isEmpty() || titulo.isEmpty() || autor.isEmpty()) {
            mensaje("Completa el código, título y autor.");
            return;
        }

        if (lista.contieneCodigo(codigo)) {
            mensaje("Ya existe un libro con ese código.");
            return;
        }

        Libro libro = new Libro(codigo, titulo, autor);

        lista.agregar(libro);
        arbol.insertar(libro);

        mostrarTodos();
        limpiarCampos();

        mensaje("Libro registrado correctamente.");
    }

    // Buscar libro utilizando el árbol binario
    private void buscarLibro() {

        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            mensaje("Escribe el código del libro.");
            return;
        }

        Libro libro = arbol.buscar(codigo);

        if (libro == null) {
            mensaje("No se encontró el libro.");
            return;
        }

        txtTitulo.setText(libro.getTitulo());
        txtAutor.setText(libro.getAutor());

        int fila = filaPorCodigo(libro.getCodigo());

        if (fila >= 0) {
            tabla.setRowSelectionInterval(fila, fila);
            tabla.scrollRectToVisible(
                    tabla.getCellRect(fila, 0, true));
        }

        mensaje("Libro encontrado.");
    }

    // Buscar una fila por código
    private int filaPorCodigo(String codigo) {

        for (int i = 0; i < modelo.getRowCount(); i++) {
            if (modelo.getValueAt(i, 0).toString()
                    .equalsIgnoreCase(codigo)) {
                return i;
            }
        }

        return -1;
    }

    // Mostrar los libros de la lista enlazada
    private void mostrarTodos() {

        modelo.setRowCount(0);

        for (Libro libro : lista.obtenerTodos()) {
            modelo.addRow(new Object[]{
                    libro.getCodigo(),
                    libro.getTitulo(),
                    libro.getAutor(),
                    libro.getEstado()
            });
        }

        actualizarResumen();
    }

    // Registrar solicitud de préstamo
    private void solicitarPrestamo() {

        String codigo = txtCodigo.getText().trim();
        String solicitante = txtSolicitante.getText().trim();

        if (codigo.isEmpty() || solicitante.isEmpty()) {
            mensaje("Escribe el código y el nombre del solicitante.");
            return;
        }

        Libro libro = arbol.buscar(codigo);

        if (libro == null) {
            mensaje("El libro no existe.");
            return;
        }

        if (libro.isPrestado()) {
            mensaje("El libro ya está prestado.");
            return;
        }

        cola.encolar(codigo, solicitante);

        txtSolicitante.setText("");
        actualizarResumen();

        mensaje("Solicitud agregada a la cola.");
    }

    // Atender la primera solicitud registrada
    private void atenderSolicitud() {

        ColaPrestamos.Solicitud solicitud = cola.desencolar();

        if (solicitud == null) {
            mensaje("No hay solicitudes pendientes.");
            return;
        }

        Libro libro = arbol.buscar(solicitud.getCodigoLibro());

        if (libro == null) {
            mensaje("El libro no existe.");
        } else if (libro.isPrestado()) {
            mensaje("El libro ya está prestado.");
        } else {
            libro.setPrestado(true);

            mensaje("Préstamo registrado para "
                    + solicitud.getSolicitante() + ".");
        }

        mostrarTodos();
    }

    // Registrar la devolución de un libro
    private void devolverLibro() {

        String codigo = txtCodigo.getText().trim();

        if (codigo.isEmpty()) {
            mensaje("Escribe el código del libro.");
            return;
        }

        Libro libro = arbol.buscar(codigo);

        if (libro == null) {
            mensaje("No se encontró el libro.");
            return;
        }

        if (!libro.isPrestado()) {
            mensaje("El libro ya está disponible.");
            return;
        }

        libro.setPrestado(false);

        mostrarTodos();
        mensaje("Devolución registrada correctamente.");
    }

    // Limpiar campos del libro
    private void limpiarCampos() {
        txtCodigo.setText("");
        txtTitulo.setText("");
        txtAutor.setText("");
    }

    // Actualizar contador
    private void actualizarResumen() {

        lblResumen.setText(
                "Libros: " + lista.getCantidad()
                        + " | Solicitudes pendientes: "
                        + cola.getCantidad());
    }

    // Mostrar mensajes
    private void mensaje(String texto) {
        JOptionPane.showMessageDialog(
                this,
                texto,
                "Biblioteca Virtual",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
