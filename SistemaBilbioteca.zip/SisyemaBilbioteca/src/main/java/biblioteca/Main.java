package biblioteca;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new BibliotecaFrame().setVisible(true);
        });
    }
}